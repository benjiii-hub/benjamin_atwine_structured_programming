mark = float(input("Enter Numeric Score"))
if mark >= 90:
    print("D1")
elif mark >= 80:
    print("D2")
elif mark >= 70:
    print("C3")
elif mark >= 60:
    print("C4")
elif mark >= 50:
    print("C5")
elif mark >= 40:
    print("C6")
elif mark <= 30:
    print("P7")
else :
    print("F")
    