mark = int(input("Enter numeric score"))
if mark in range(80,100):
    print("A")
elif mark in range(70,79):
    print("B")
elif mark in range(60,69):
    print("C")
elif mark in range(50,59):
    print("D")
else:
    print("F")
