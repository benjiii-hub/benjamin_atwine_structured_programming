## user input
length = float(input("Enter the length"))
width = float(input("Enter the width"))

## area
area = length*width
print("The area is", area)

## perimeter
perimeter = 2*(length+width)
print("The perimeter is", perimeter)