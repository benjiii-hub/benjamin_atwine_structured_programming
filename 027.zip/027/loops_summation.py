n = float(input("Enter positive number"))

while True:
            n = float(input("Enter positive number"))
            if n > 0:
                print("Thank you. Your no. is", n)
            else:
                 print("The number must be positive. try again!")

def sum_of_even_numbers(n):
       total = 0
       for i in range(2, n+1, 2):
              total += i
              return total
       