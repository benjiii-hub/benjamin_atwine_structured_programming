mark = float(input("Enter Numeric Score"))
if mark >= 80:
    print("A")
elif mark >= 70:
    print("B")
elif mark >= 60:
    print("C")
elif mark >= 50:
    print("D")
else :
    print("F")

    