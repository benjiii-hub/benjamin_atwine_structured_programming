numbers = []
for i in range(5):
    num = float(input(f"Enter number {i + 1}: "))
    numbers.append(num)
print("List of numbers", numbers)
maximum = max(numbers)
minimum = min(numbers)
average = sum(numbers) / len(numbers)
print("Maximum:", maximum)
print("Minimum:", minimum)
print("Average:", average)

sorted_numbers = sorted(numbers)
print("Sorted list of numbers:", sorted_numbers)