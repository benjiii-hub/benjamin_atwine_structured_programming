## Assigning a variable refers to specifying what kind of data type a variable will have while
# Declaring a variable refers to checking or specifying the data type of a given varible.

## Declaring
age = 25
first_letter = 'B'

##Assigning
print(type(first_letter))
