print("Welcome to Grading System")
number = int(input("Please enter a number between 0 and 100"))
if number >= 90:
    print("A+")
elif number >= 80:
    print("A")
elif number >= 70:
    print("B")
elif number >= 60:
    print("C")
elif number >= 50:
    print("D")
elif number >= 40:
    print("E")
elif number <= 30:
    print("F")
else :
    print("F")