## Conversions

age = 8
new_age = float(age)
print(f"float: {new_age}")

length = 56.90
new_length = int(length)
print(f"integer: {new_length}")

height = 34.0994
new_height = int(height)
print(f"integer:{new_height}")
